﻿using System;


public enum ChessPieceColor
{
    Black, White
}
public enum ChessPieceType
{
    Pawn, Rook, Knight, Bishop, King, Queen
}