﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assignment1
{
    class ChessPiece
    {
        public ChessPieceColor color;
        public ChessPieceType type;
    }
}
