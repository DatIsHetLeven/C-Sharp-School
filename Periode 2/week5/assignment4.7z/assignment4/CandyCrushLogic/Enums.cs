﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CandyCrushLogic
{
    /*
        * Creating enum for regular candies
        */
    public enum RegularCandies
    {
        None = -1,
        //red
        JellyBean,
        //orange
        Lozenge,
        //yellow
        LemonDrop,
        //green
        GumSquare,
        //blue
        LollipopHead,
        //purple
        JujubeCluster
    }

}
